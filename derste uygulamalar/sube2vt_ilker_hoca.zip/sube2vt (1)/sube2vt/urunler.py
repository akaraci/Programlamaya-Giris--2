# -*- coding: utf-8 -*-
"""
Created on Tue May 14 17:24:23 2024

@author: akara
"""

from urunlerui import *
from PyQt5.QtWidgets import *
import sys
import sqlite3

class pageProduct(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.ui.leproductid.setEnabled(False)
        self.ui.leproductname.setInputMask("a"*40) # sadece 40 adet harf girilebilir.
        self.currow=0
        #database configuration
        self.conn=sqlite3.Connection("products.db") #veri tabanı varsa açar ve yoksa oluşturur
        self.curs=self.conn.cursor()  ##sql komutlarını kullanmak execute etmek için cursor nesnesi kullanılır
        
        #signal slot
        self.ui.btnyeni.clicked.connect(self.YENI)
        self.ui.btnekle.clicked.connect(self.EKLE)
        
        self.BOLUMLERI_DOLDUR()
        self.sqlgenel="SELECT p.productid,p.productname,c.categoryname FROM urunler as p, kategori as c WHERE p.categoryid=c.categoryid"
        self.TableWidgettaGoster(self.sqlgenel)
        
    def YENI(self):
        self.ui.leproductname.setText("")
        self.ui.leproductname.setFocus(True) #True derseniz en başa konumlanır. False en sona
    
    def BOLUMLERI_DOLDUR(self):
        select_sql="SELECT * FROM kategori"
        result=list(self.curs.execute(select_sql))
        for index, item in enumerate(result):
            self.ui.cmbcategoryname.insertItem(index,item[1],item[0]) #index, text:bkategorimadı (item[1]), value:kategori kodu (item[0])
            self.ui.cmbkategoriara.insertItem(index,item[1],item[0])
    
    def TableWidgettaGoster(self,sql):
        result=list(self.curs.execute(sql)) #veri çekiliyor ve list veri tipine çevriliyor
        print(result)
        rowcount=len(result) #kayıt sayısı elde ediliyor
        self.ui.lbkayit.setText("Kayıt Sayısı="+str(rowcount))
        self.ui.tableWidget1.setRowCount(rowcount)
        for rowindex,rowdata in enumerate(result): #sorgudan dönen satırlar (list row)
            for colindex,coldata in enumerate(rowdata): #sorgudan elde edilen sütun verisi
                self.ui.tableWidget1.setItem(rowindex,colindex,QTableWidgetItem(str(coldata)))
        
        self.ui.tableWidget1.setCurrentCell(self.currow,0) #setCurrentCell(curentrow,curentcell)
    
    def EKLE(self):
        insertsql="INSERT INTO urunler (productname,categoryid) VALUES(?,?)"
        _categoryid=self.ui.cmbcategoryname.currentData()
        _productname=self.ui.leproductname.text()
        parameter=[_productname,_categoryid]
        self.curs.execute(insertsql,parameter)
        self.conn.commit()
        self.currow=self.ui.tableWidget1.rowCount() #kayıt eklendikten sonra son kayda git ve seç
        self.TableWidgettaGoster(self.sqlgenel)
        QMessageBox().information(self,"Bilgilendirme","Kaydınız Eklendi")
    
    
if (__name__=="__main__"):
    app=QApplication(sys.argv) ##application oluşturuluyor
    window=pageProduct()
    window.show()
    sys.exit(app.exec_()) #pencereden çıkarken uygulama ile lgili tüm işlemler sonlandırılıyor