# -*- coding: utf-8 -*-
"""
Created on Thu May 16 11:39:37 2024

@author: akara
"""

from PyQt5.QtWidgets import *
import sys
import sqlite3
from kategoriui import *

class pageCategory(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        self.ui.lecategoryid.setEnabled(False)
        self.currow=0
        #database configuration
        self.conn=sqlite3.Connection("products.db") #veri tabanı varsa açar ve yoksa oluşturur
        self.curs=self.conn.cursor()  ##sql komutlarını kullanmak execute etmek için cursor nesnesi kullanılır
        
        #signal-slots
        self.ui.btnyeni.clicked.connect(self.YENI)
        self.ui.btnekle.clicked.connect(self.EKLE)
        self.ui.btnonceki.clicked.connect(self.ONCEKI)
        self.ui.btnsonraki.clicked.connect(self.SONRAKI)
        self.ui.tableWidget1.itemSelectionChanged.connect(self.itemSelectionChanged)
        self.ui.btnsil.clicked.connect(self.SIL)
        self.ui.btnduzelt.clicked.connect(self.DUZELT)
        self.ui.lefindcategoryname.textChanged.connect(self.ARA)
        
        self.sqlgenel="SELECT * FROM kategori"
        self.TablewidgettaGoster(self.sqlgenel)
        if (self.ui.tableWidget1.rowCount()>0):
            self.ui.tableWidget1.setCurrentCell(self.currow,0)
        
    def YENI(self):
        self.ui.lecategoryname.setText("")
        self.ui.lecategoryname.setFocus()
    
    def EKLE(self):
        _categoryname=self.ui.lecategoryname.text()
        sql="INSERT INTO kategori (categoryname) VALUES (?)"
        parameter=[_categoryname]
        self.curs.execute(sql,parameter)
        self.conn.commit()
        QMessageBox().information(self,"Bilgilendirme","Kaydınız Eklendi")
        self.TablewidgettaGoster(self.sqlgenel)
    
    def TablewidgettaGoster(self,sql):
        result=list(self.curs.execute(sql))
        print(result)
        rowcount=len(result)
        self.ui.tableWidget1.setRowCount(rowcount)
        self.ui.progressBar1.setMaximum(rowcount)
        for rowindex,rowdata in enumerate(result):
            for colindex,coldata in enumerate(rowdata):
                self.ui.tableWidget1.setItem(rowindex,colindex,QTableWidgetItem(str(coldata)))

        
    
    def ONCEKI(self):
        self.currow-=1
        if (self.currow==-1):
            self.currow=self.ui.tableWidget1.rowCount()-1
        self.ui.tableWidget1.setCurrentCell(self.currow,0)   
    
    def SONRAKI(self):
        self.currow+=1
        if (self.currow==self.ui.tableWidget1.rowCount()):
            self.currow=0
        self.ui.tableWidget1.setCurrentCell(self.currow,0)
    
    def itemSelectionChanged(self):
        #print("Seçili madde değişti")
        index=self.ui.tableWidget1.currentIndex();
        self.currow=index.row()
        self.ui.progressBar1.setValue(self.currow+1)
        self.TabletoForm()
        
    
    def TabletoForm(self):
        selectedrows=self.ui.tableWidget1.selectedItems()
        self.ui.lecategoryid.setText(selectedrows[0].text())
        self.ui.lecategoryname.setText(selectedrows[1].text())
        

    def SIL(self):
        selectedrows=self.ui.tableWidget1.selectedItems()
        silinen=selectedrows[0].text()
        response=QMessageBox().question(self,"Silme Onay",
                                         "Seçili kaydı silmek istediğinize emin misin?",
                                         QMessageBox().Yes| QMessageBox().No)
        if response==QMessageBox().Yes:
            sql="DELETE FROM kategori WHERE categoryid=?"
            parameter=[silinen]
            self.curs.execute(sql,parameter)
            self.conn.commit()
            QMessageBox().information(self,"Bilgilendirme",str(silinen)+" idli Kayıt Silindi")
            self.TablewidgettaGoster(self.sqlgenel)
    
    def DUZELT(self):
        print("cuurow=",self.currow)
        duzeltsql="update kategori SET categoryname=? WHERE categoryid=?"
        selectedrow=self.ui.tableWidget1.selectedItems()
        categoryid=selectedrow[0].text()
        parameter=[self.ui.lecategoryname.text(),categoryid]
        self.curs.execute(duzeltsql,parameter)
        self.conn.commit()
        QMessageBox().information(self,"Bilgilendirme",str(categoryid)+" idli Kayıt Güncellendi")
        self.TablewidgettaGoster(self.sqlgenel)
    
    def ARA(self):
        sql="SELECT * FROM kategori WHERE categoryname LIKE'%"+self.ui.lefindcategoryname.text()+"%'"
        self.TablewidgettaGoster(sql)
    
if (__name__=="__main__"):
    app=QApplication(sys.argv) ##application oluşturuluyor
    window=pageCategory()
    window.show()
    sys.exit(app.exec_()) #pencereden çıkarken uygulama ile lgili tüm işlemler sonlandırılıyor















