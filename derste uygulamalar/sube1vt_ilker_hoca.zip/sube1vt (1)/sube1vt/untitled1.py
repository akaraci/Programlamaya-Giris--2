# -*- coding: utf-8 -*-
"""
Created on Thu May 16 09:36:59 2024

@author: akara
"""

