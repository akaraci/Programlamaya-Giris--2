# -*- coding: utf-8 -*-
"""
Created on Thu May 16 11:35:22 2024

@author: akara
"""

from PyQt5 import uic

with open("kategoriui.py",'w', encoding="utf-8") as fout:
    uic.compileUi("kategori.ui", fout)