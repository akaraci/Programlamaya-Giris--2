# -*- coding: utf-8 -*-
"""
Created on Thu May 16 09:42:42 2024

@author: akara
"""

from PyQt5.QtWidgets import *
import sys
import sqlite3
from kategoriui import *

class pageCategory(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui=Ui_Dialog()
        self.ui.setupUi(self)
        
        self.ui.lecategoryid.setEnabled(False)
        
        #database configuration
        self.conn=sqlite3.Connection("products.db") #veri tabanı varsa açar ve yoksa oluşturur
        self.curs=self.conn.cursor()  ##sql komutlarını kullanmak execute etmek için cursor nesnesi kullanılır
    
        #signal slot
        self.ui.btnyeni.clicked.connect(self.YENI)
        self.ui.btnekle.clicked.connect(self.EKLE)
        
        
    def YENI(self):
        self.ui.lecategoryname.setText("")
        self.ui.lecategoryname.setFocus()
    
    def EKLE(self):
        _categoryname=self.ui.lecategoryname.text()
        sql="INSERT INTO kategori (categoryname) VALUES (?)"
        parameter=[_categoryname]
        self.curs.execute(sql,parameter)
        self.conn.commit()
        QMessageBox().information(self,"Bilgilendirme","Kaydınız Eklendi")


if (__name__=="__main__"):
    app=QApplication(sys.argv) ##application oluşturuluyor
    window=pageCategory()
    window.show()
    sys.exit(app.exec_()) #pencereden çıkarken uygulama ile lgili tüm işlemler sonlandırılıyor











    